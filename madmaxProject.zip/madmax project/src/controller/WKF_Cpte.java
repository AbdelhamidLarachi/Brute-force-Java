package controller;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;

import view.FRM_Auth;
import model.Map_P;
import model.CAD;


public class WKF_Cpte
{
    private final FRM_Auth view;
    
    private final Map_P map;
    
    private final CAD cad;
    
    private MessageDigest md;

    
    public WKF_Cpte(final CAD cad)
    {
        this.view = new FRM_Auth(this);
        
        this.map = new Map_P();
        this.cad = cad;
        

        try
        {
            this.md = MessageDigest.getInstance("MD5");
        }
        catch (final NoSuchAlgorithmException e)
        {
            this.md = null;
        }
    }
    
// on close : 
    
    public void OnClose()
    {
        this.view.getFrame().dispose();
        System.exit(0);
    }
    
  // correct operation 
    
    public void OnLogin()
    {
        this.view.getFrame().dispose();
        new WKF_Decrypt(cad);
    }
    
   
    public boolean pcs_authentifier(final String login, final String password)
    {
        // On hash le mot de passe en MD5 :
        this.md.update(password.getBytes());
        
        byte[] bytes = this.md.digest();
        
        StringBuilder sb = new StringBuilder();
        
        for (int i = 0; i < bytes.length; i++)
            sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
        
        final String passwordMD5 = sb.toString();
        
        // On récupère la requête SQL à soumettre :
        final String sql = map.selectIDbyLoginPassword(login, passwordMD5);
        
        // On interroge la base de données sur le login/password :
        try
        {
            final ResultSet rs = cad.GetRows(sql);
            
            if (rs.next())
            {
                rs.close();
                return true;
            }
            
            rs.close();
        }
        catch (final SQLException e)
        {
        }

        return false;
    }
}
