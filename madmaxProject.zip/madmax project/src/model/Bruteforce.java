package model;

import javax.swing.JLabel;
import java.awt.Color;
import java.sql.SQLException;

import controller.WKF_Decrypt;


public class Bruteforce implements Runnable
{
    private final WKF_Decrypt controller;
        private final JLabel infoLabel;
        private final DecryptResult result;
    
    private final String data;          
    private final String destination;   
    private final String lkey;          
    private final int charLeft;       
    private final long toBruteforce;    
    private final int[] tempKey;       
    private final char[] tempKeyChar;   
    
    private final int KEY_ALPHABET_LENGTH = 26;
    
    private final char[] KEY_ALPHABET = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    
  
    public Bruteforce(final WKF_Decrypt controller, final String data, final String destination, final String key, final int charLeft, final DecryptResult result)
    {
        this.controller = controller;
        this.infoLabel = controller.getView().getHeaderLabel();
        this.result = result;
        
        this.data = data;
        this.destination = destination;
        this.lkey = key;
        this.charLeft = charLeft;
        this.toBruteforce = (long)Math.pow(KEY_ALPHABET_LENGTH, charLeft);
        this.tempKey = new int[charLeft];
        this.tempKeyChar = new char[charLeft];
    }
    
    private void shiftKey(final int[] key, final int l)
    {
        for (int i = 0; i < l; i++)
        {
            key[i]++;
            
            if (key[i] >= KEY_ALPHABET_LENGTH)
                key[i] = 0;
            else
                return;
        }
    }
    
   
    public void run()
    {
        String decrypted = "";
        String testKey;

        for (int i = 0; i < this.charLeft; i++)
            this.tempKey[i] = KEY_ALPHABET[0];

        this.infoLabel.setForeground(Color.black);
        this.infoLabel.setText("Clefs utilisés : 0 / " + toBruteforce + " (0 % testés)...");

        for (long i = 0; i < this.toBruteforce; i++)
        {
            this.shiftKey(this.tempKey, this.charLeft);

            for (int j = 0; j < this.charLeft; j++)
                this.tempKeyChar[j] = KEY_ALPHABET[this.tempKey[j]];

            testKey = this.lkey + new String(this.tempKeyChar);

            // On tente un décryptage :
            decrypted = this.controller.getDecrypter().decrypt(this.data, testKey);

            // On compare avec le dictionnaire chacun des mots pour contrôler la validité de la clef :
            try
            {
                if (this.controller.checkDictionary(decrypted))
                {
                    this.result.key = testKey;
                    this.result.recognized = true;
                    
                    break;
                }
            }
            catch (final SQLException e)
            {
            }
            
            // On donne des infos sur la progression du bruteforce :
            this.infoLabel.setText("Clefs utilisés : " + i + " / " + this.toBruteforce + " (" + (int)(((float)i / (float)this.toBruteforce) * 100.0f) + " % testés)...");
        }
        
        // On signale au contrôleur que le thread est terminé :
        this.controller.onFinished(this.destination, decrypted, this.result);
    }
}
