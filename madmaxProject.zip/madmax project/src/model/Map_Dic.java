package model;


public class Map_Dic
{
   
    public String selectWord(final String word)
    {
        return "SELECT * FROM `dict` WHERE `word` = '" + word + "';";
    }
}
