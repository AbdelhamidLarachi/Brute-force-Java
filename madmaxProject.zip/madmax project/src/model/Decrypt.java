package model;

public class Decrypt
{

    public String decrypt(String data, String key)
    {
        char[] outputString = new char[data.length()];
        
        int key_i = 0;
        
        for (int i = 0; i < data.length(); i++)
        {
            outputString[i] = (char)(data.charAt(i) ^ key.charAt(key_i));
            
            // On décale dans la clef :
            if (key_i < key.length()-1)
                key_i++;
            else
                key_i = 0;
        }
        
        // on retourne la chaîne de caractère déchiffrée :
        return new String(outputString);
    }
}
