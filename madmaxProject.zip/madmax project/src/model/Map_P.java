package model;


public class Map_P
{
    
    public String selectIDbyLoginPassword(final String login, final String password)
    {
        return "SELECT * FROM `user` WHERE `username` = '" + login + "' AND `password` = '" + password + "';";
    }
}
