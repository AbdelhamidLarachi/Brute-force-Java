package model;

/**
 * @author Matthieu Carteron
 */
public class DecryptResult
{

    public boolean succeed = false;
    
    public boolean recognized = false;
    
    public String key = "";
}
