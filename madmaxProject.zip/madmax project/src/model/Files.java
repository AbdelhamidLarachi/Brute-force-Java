package model;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Files
{

    // import
	
	public String getData(final String path) throws IOException
    {
        final FileReader reader = new FileReader(path);

        String data = "";
        int c = reader.read();
        
        while (c != -1)
        {
            data += (char)c;
            c = reader.read();
        }

        reader.close();
        
        return data;
    }
    
	// export

    public void setData(final String path, final String data) throws IOException
    {
        final FileWriter writer = new FileWriter(path);
        
        writer.write(data);
        writer.close();
    }
}
