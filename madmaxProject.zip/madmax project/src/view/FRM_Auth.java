package view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.BoxLayout;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import controller.WKF_Cpte;
import com.jgoodies.forms.factories.DefaultComponentFactory;


public class FRM_Auth
{
    private final WKF_Cpte controller;
    
    private final JFrame frame;
    
    private final String DIALOG_TITLE = "Authentification";
    
    
    public FRM_Auth(final WKF_Cpte controller)
    {
        this.controller = controller;
        this.frame = new JFrame(DIALOG_TITLE);
        
        this.InitWindow();
    }
    
    // Initialise la fenêtre :
    private void InitWindow()
    {
        // Création des panneaux :
        final JPanel panel = new JPanel();
        final JPanel pheader = new JPanel();
        final JPanel plogin = new JPanel();
        final JPanel ppassword = new JPanel();
        final JPanel pconfirm = new JPanel();
                
        // Labels :
        final JLabel lheader = new JLabel("Veuillez entrer les informations d'authentification.", SwingConstants.CENTER);
        final JLabel llogin = new JLabel("USERNAME");
        llogin.setHorizontalAlignment(SwingConstants.CENTER);
        final JLabel lpassword = new JLabel("PASSWORD");
        lpassword.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Bouton de confirmation :
        final JButton confirm = new JButton("CONNECT");
        
        // Champs de texte :
        final JTextField login = new JTextField();
        login.setHorizontalAlignment(SwingConstants.CENTER);
        final JPasswordField password = new JPasswordField();
        password.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Positionnement & paramétrage des widgets :
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        pheader.setBorder(new EmptyBorder(2, 2, 2, 2));
        plogin.setLayout(new GridLayout(1, 2));
        plogin.setBorder(new EmptyBorder(20, 50, 5, 70));
        ppassword.setLayout(new GridLayout(1, 2));
        ppassword.setBorder(new EmptyBorder(5, 50, 5, 70));
        pconfirm.setLayout(new BorderLayout());
        pconfirm.setBorder(new EmptyBorder(10, 80, 5, 65));        
        confirm.addActionListener(new ActionListener()
        {

        	public void actionPerformed(ActionEvent e)
            {
                // On teste les identifiants entrés :
                if (controller.pcs_authentifier(login.getText(), new String(password.getPassword())))
                    controller.OnLogin();
                else
                {
                	 lheader.setText("Erreur ! Login ou mot de passe invalide !");
                     lheader.setForeground(Color.red);
                }
            }
        });
        
        // Ajout des widgets :
        pheader.add(lheader);
        plogin.add(llogin);
        plogin.add(login);                
        ppassword.add(lpassword);
        ppassword.add(password);        
        pconfirm.add(confirm, BorderLayout.NORTH);        
        panel.add(pheader);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBorder(new EmptyBorder(10, 70, 10, 70));
        pheader.add(panel_1);
        
        JLabel lblGroupe = DefaultComponentFactory.getInstance().createLabel("Séminaire sientifique - Groupe 2");
        lblGroupe.setHorizontalAlignment(SwingConstants.CENTER);
        panel_1.add(lblGroupe);
        panel.add(plogin);
        panel.add(ppassword);
        panel.add(pconfirm);
        
        frame.getContentPane().add(panel, BorderLayout.NORTH);
        // Paramétrage de la fenêtre :
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        frame.setSize(405, 223);
        frame.setLocationRelativeTo(null);
        
        frame.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
                controller.OnClose();
            }
        });
        
        frame.setVisible(true);
    }
    
    
    public JFrame getFrame()
    {
        return this.frame;
    }
}
