package view;

import javax.swing.JLabel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.PlainDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;


public class KeyTextField extends PlainDocument implements DocumentListener
{
    // Référence sur le label de la clef :
    private final JLabel keyLabel;
    
    // Le nombre de caractère limite :
    private final int limit;

    
    public KeyTextField(final JLabel keylabel, int limit)
    {
        super();
        
        this.addDocumentListener(this); // On ajoute l'objet lui-même en tant que listener.
        
        this.keyLabel = keylabel;
        this.limit = limit;
    }
    
    // Exécutée lorsque des caractères sont insérés :
    public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException
    {
        if (str == null)
            return;

        if ((getLength() + str.length()) <= limit)
            super.insertString(offset, str, attr);
    }

    public void insertUpdate(DocumentEvent e)
    {
        this.changeString(getLength());
    }

    public void removeUpdate(DocumentEvent e)
    {
        this.changeString(getLength());
    }

    // Exécutée lorsque le champ est changé :
    public void changedUpdate(DocumentEvent e)
    {
        this.changeString(getLength());
    }
    
    // Change le label de la clef :
    private void changeString(int length)
    {
        this.keyLabel.setText("Clef : " + length + " / 12 caractères (à Bruteforce : " + (12-length) + ") :");
    }
}